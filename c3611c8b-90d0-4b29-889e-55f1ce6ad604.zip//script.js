class Calendar {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.daysOfWeek = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    this.startDate = new Date();
    this.startDate.setDate(this.startDate.getDate() - this.startDate.getDay());
    this.selectedCell = null;
  }
  updateTitleWithDateRange() {
    const titleElement = document.querySelector("h2.text-center");
    const startDate = new Date(this.startDate);
    const endDate = new Date(this.startDate);
    endDate.setDate(startDate.getDate() + 6);

    const startDay = startDate.getDate().toString().padStart(2, "0");
    const startMonth = (startDate.getMonth() + 1).toString().padStart(2, "0");
    const endDay = endDate.getDate().toString().padStart(2, "0");
    const endMonth = (endDate.getMonth() + 1).toString().padStart(2, "0");

    titleElement.textContent = `PROGRAMS FOR ALL CROPS ${startDay}/${startMonth}-${endDay}/${endMonth}`;
  }

  generateHeader() {
    const calendarHeader = document.getElementById("calendarHeader");
    calendarHeader.innerHTML = "";

    const emptyHeaderCell = document.createElement("th");
    emptyHeaderCell.classList.add("hour-header");
    calendarHeader.appendChild(emptyHeaderCell);

    for (let day = 0; day < 7; day++) {
      const currentDay = new Date(this.startDate);
      currentDay.setDate(this.startDate.getDate() + day);

      const dayName = this.daysOfWeek[currentDay.getDay()];
      const dayNumber = currentDay.getDate();
      const headerCell = document.createElement("th");
      headerCell.classList.add("day-header");

      if (day > 0) {
        headerCell.style.borderLeft = "2px solid black";
      }

      headerCell.innerHTML = `<span class="day-name">${dayName}</span><br><small class="date">${dayNumber}</small>`;
      calendarHeader.appendChild(headerCell);
    }
  }

  generateBody() {
    const calendarBody = document.getElementById("calendarBody");
    calendarBody.innerHTML = "";

    for (let hour = 7; hour < 31; hour++) {
      const actualHour = hour % 24;
      const row = document.createElement("tr");

      const hourCell = document.createElement("td");
      hourCell.classList.add("hour-cell");

      if (actualHour === 7) {
        hourCell.innerHTML = `<img src="SUNLOGO.svg" alt="Sun" class="time-icon"> ${actualHour}:00`;
      } else if (actualHour === 16) {
        hourCell.innerHTML = `<img src="SUNSETLOGO.svg" alt="Sunset" class="time-icon"> ${actualHour}:00`;
      } else if (actualHour === 0) {
        hourCell.innerHTML = `<img src="MOON.svg" alt="Moon" class="time-icon"> 00:00`;
      } else {
        hourCell.textContent = `${actualHour === 0 ? "00" : actualHour}:00`;
      }

      if (actualHour === 16 || actualHour === 0) {
        row.style.borderTop = "2px solid black";
      }

      hourCell.style.backgroundColor =
        actualHour >= 7 && actualHour <= 15
          ? "#FFF8E4"
          : actualHour >= 16 && actualHour <= 23
          ? "#E4FDFF"
          : "#E5E4FF";

      row.appendChild(hourCell);

      for (let day = 0; day < 7; day++) {
        const cell = document.createElement("td");
        cell.classList.add("calendar-cell");
        cell.id = `cell-${day}-${actualHour}`;

        if (day > 0) cell.style.borderLeft = "2px solid black";
        if (actualHour === 16 || actualHour === 0)
          cell.style.borderTop = "2px solid black";

        cell.style.backgroundColor =
          actualHour >= 7 && actualHour <= 15
            ? "#FFF8E4"
            : actualHour >= 16 && actualHour <= 23
            ? "#E4FDFF"
            : "#E5E4FF";

        cell.textContent = ` `;
        cell.onclick = () => this.openAddEventModal(cell);
        row.appendChild(cell);
      }

      calendarBody.appendChild(row);
    }
  }

  addCurrentTimeLine() {
    const now = new Date(); // התאריך והשעה הנוכחיים
    const currentHour = now.getHours(); // השעה הנוכחית
    const currentDay = now.getDay(); // היום הנוכחי (0 = ראשון)

    const rows = document.querySelectorAll("#calendarBody tr");
    rows.forEach((row) => {
      const hourCell = row.querySelector(".hour-cell");
      if (hourCell && hourCell.textContent.startsWith(`${currentHour}:`)) {
        const currentCell = row.querySelector(
          `#cell-${currentDay}-${currentHour}`
        );
        if (currentCell) {
          currentCell.style.position = "relative";

          // יצירת נקודה אדומה
          const redDot = document.createElement("div");
          redDot.classList.add("red-dot");
          currentCell.appendChild(redDot);

          // יצירת הקו האדום
          const redLine = document.createElement("div");
          redLine.classList.add("red-line");
          currentCell.appendChild(redLine);
        }
      }
    });

    // צביעת היום והשעה הנוכחיים בכותרת
    const dayHeaders = document.querySelectorAll(".day-header");
    dayHeaders.forEach((header, index) => {
      if (index === currentDay) {
        header.querySelector(".day-name").classList.add("current-day-header");
        header.querySelector(".date").classList.add("current-date");
      }
    });
  }
  openAddEventModal(cell) {
    this.selectedCell = cell;
    const modal = new bootstrap.Modal(
      document.getElementById("addCalendarModal")
    );
    modal.show();
  }

  submitCalendar() {
    const act1 = document.getElementById("act1").value;
    const desc = document.getElementById("desc").value;
    const stime = document.getElementById("stime").value;
    const etime = document.getElementById("validity").value;

    if (!act1 || !desc || !stime || !etime) {
      alert("Please fill all fields.");
      return;
    }

    const startHour = parseInt(stime.split(":")[0]);
    const startMinutes = parseInt(stime.split(":")[1]);
    const endHour = parseInt(etime.split(":")[0]);
    const endMinutes = parseInt(etime.split(":")[1]);

    const day =
      Array.from(this.selectedCell.parentNode.children).indexOf(
        this.selectedCell
      ) - 1;

    for (let hour = startHour; hour <= endHour; hour++) {
      const cell = document.getElementById(`cell-${day}-${hour}`);
      if (cell) {
        let style = "";
        const originalColor =
          cell.style.backgroundColor || this.getTimeCellColor(hour);

        // צביעה חלקית לתא ההתחלה
        if (hour === startHour && startMinutes > 0) {
          const percentage = (startMinutes / 60) * 100;
          style = `linear-gradient(to bottom, ${originalColor} ${percentage}%, #18AC00 ${percentage}%)`;
        }
        // צביעה חלקית לתא הסיום
        else if (hour === endHour && endMinutes > 0) {
          const percentage = (endMinutes / 60) * 100;
          style = `linear-gradient(to top, ${originalColor} ${
            100 - percentage
          }%, #18AC00 ${100 - percentage}%)`;
        }
        // צביעה מלאה
        else {
          cell.style.backgroundColor = "#18AC00";
          cell.style.color = "#FFFFFF";
        }

        if (style) {
          cell.style.background = style;
        }

        cell.innerHTML = `${desc}`;
        cell.style.color = "#FFFFFF";
        cell.title = `${hour}:00, ${desc}`;
      }
    }

    const modal = bootstrap.Modal.getInstance(
      document.getElementById("addCalendarModal")
    );
    modal.hide();
  }

  /**
   * Helper function to determine the default background color based on the time of day.
   */
  getTimeCellColor(hour) {
    if (hour >= 7 && hour <= 15) {
      return "#FFF8E4"; // בוקר
    } else if (hour >= 16 && hour <= 23) {
      return "#E4FDFF"; // צהריים
    } else {
      return "#E5E4FF"; // ערב
    }
  }

  initialize() {
    this.generateHeader();
    this.generateBody();
    this.addCurrentTimeLine(); // עדכון היום והשעה הנוכחיים
    this.updateTitleWithDateRange();
  }
}

const calendar = new Calendar("calendarContainer");
calendar.initialize();
